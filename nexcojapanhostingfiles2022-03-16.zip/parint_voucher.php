<?php if ($_REQUEST['var']) {
	echo $transcation_id = $_REQUEST['var'];

	# code...
} ?>


 